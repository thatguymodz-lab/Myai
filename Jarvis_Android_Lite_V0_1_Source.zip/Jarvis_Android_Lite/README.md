# Jarvis Android Lite V0.1

Android-native starter for the desktop Jarvis project.

## Included now
- Native Android Jetpack Compose TALK UI
- FAST/local-first design shell
- Android permissions for internet and microphone
- GitHub Actions APK build workflow
- No laptop is required to *use* an APK once built/installed

## Local AI integration target
Use the official llama.cpp Android binding (`examples/llama.android`) and a GGUF model. The current starter intentionally does not pretend the Windows Python/Ollama runtime can run unchanged on Android.

## Build
Open in Android Studio with Android SDK 36 / Java 17, or push to GitHub and run the included Build Android APK workflow.

## Planned modules
1. llama.cpp GGUF inference and model manager
2. Streaming TALK replies and context memory
3. Android speech input/output
4. Web research
5. One-file HTML/CSS/JS quick website builder
6. WebView preview and project files
7. Build queue/status and repair checks

The desktop V132 code is a behavior/reference source; Windows-only Python/Tk/subprocess/Ollama code must be replaced with Android-native equivalents.
