package com.novajarvis.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp() }
    }
}

data class Msg(val who: String, val text: String)

@Composable
fun JarvisApp() {
    val bg = Color(0xFF030A12)
    val cyan = Color(0xFF42D9FF)
    var input by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf(Msg("JARVIS", "Android core ready. Local AI runtime is the next module.")) }
    MaterialTheme(colorScheme = darkColorScheme(primary = cyan, background = bg, surface = Color(0xFF071522))) {
        Column(Modifier.fillMaxSize().background(bg).padding(16.dp)) {
            Text("JARVIS // ANDROID LITE", color = cyan, style = MaterialTheme.typography.headlineSmall)
            Text("FAST • TALK • LOCAL-FIRST", color = Color.LightGray)
            Spacer(Modifier.height(12.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(messages) { m ->
                    Text("${m.who}: ${m.text}", color = if (m.who == "YOU") Color.White else cyan, modifier = Modifier.padding(vertical = 7.dp))
                }
            }
            Row(Modifier.fillMaxWidth()) {
                OutlinedTextField(input, { input = it }, modifier = Modifier.weight(1f), label = { Text("Talk to Jarvis") })
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    val q = input.trim(); if (q.isNotEmpty()) {
                        messages += Msg("YOU", q)
                        messages += Msg("JARVIS", "I received that. Connect a GGUF model to enable offline answers.")
                        input = ""
                    }
                }) { Text("TALK") }
            }
        }
    }
}
